# Beyond Logic — Nightly Master Bundle (2025-09-16)

Contents:
- scripts/ (Issue 1 JSON + TXT)
- environments/ (sample living room manifest)
- storyboards/ (p12_p2 shot_spec)
- characters/, props/, reports/, tools/ placeholders

## How to use
1. Save this zip into iCloud Drive > BeyondLogic > archives
2. In Working Copy, add the zip under archives/
3. Commit & push with message:
   nightly-20250916 snapshot
