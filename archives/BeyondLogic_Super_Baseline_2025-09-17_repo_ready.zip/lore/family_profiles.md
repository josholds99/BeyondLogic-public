# Family Profiles

Josh (grit), Bailey (warmth), Everett (playful), Collin (teen).
