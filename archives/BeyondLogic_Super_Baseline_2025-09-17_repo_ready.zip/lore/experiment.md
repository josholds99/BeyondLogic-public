# The Experiment

A rogue Watcher catalyzes Collin; he chooses himself.
