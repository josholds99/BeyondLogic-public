# Series Arc Notes

Issue 1–10 skeleton; AI → Watchers arc.
