# Complete Baseline Super‑Bundle — 2025-09-17

## Archive
- Save this zip to iCloud Drive / BeyondLogic / archives/
- In Working Copy: add to archives/ → commit: baseline-20250917 snapshot
- Push

## Promote (first time baseline)
- Promote these folders into your repo working tree:
  - environments/  (anchors + overhead)
  - characters/    (Collin CharacterKit v20250916; add others when ready)
  - storyboards/issue01/ (p12 panels approved; others scaffold later)
  - scripts/       (issue01.md + skeletons)
  - lore/          (backstory docs)
  - tools/         (guardrails pack)
  - reports/       (audits + render log)

- Commit: promote: complete baseline (envs + chars + storyboards + scripts + tools + lore)
- Push

## Notes
- Guardrails enforce single panel, blockout-first, CharacterKit usage, and anchors.
- Use prompt hashes + render log for reproducible panels.
