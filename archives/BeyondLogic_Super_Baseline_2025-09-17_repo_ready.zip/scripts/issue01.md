# Issue 1 — Beyond Logic

(Placeholder) 24-page script locked here.
