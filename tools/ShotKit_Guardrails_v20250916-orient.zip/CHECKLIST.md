
# ShotKit Guardrails (v20250916-orient)

**Purpose:** prevent drift by enforcing B/W, single panel, and *geometry-aware* anchors.

## Flow
1) Edit ONE shot spec (see examples/).
2) Run guardrail lint (`panel_lint.lint_shot`) — fix any errors.
3) Build prompt (`prompt_builder.compile_prompt`) — includes explicit geometry instructions.
4) Render ONE panel only.
5) Approve → assemble sheets later.

## Geometry Anchors
Use `anchors_expected` → for beds:
```json
{
  "id":"bed_W1","type":"bed","wall":"W","region":"center_horizontal",
  "orientation":"horizontal","headboard_wall":"N"
}
```
This compiles to: *“Bed under west window, headboard fixed to north wall (right side), horizontal left-to-right.”*

## Examples
- `examples/p12_p2_shot.json` → POV, no characters, bed geometry enforced.
