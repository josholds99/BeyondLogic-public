
def compile_prompt(spec: dict) -> str:
    ctrl = spec.get("render_controls", {"bw_only": True, "allow_characters": False, "single_panel_mode": True})
    camera = spec["camera"]
    comp = spec["composition"]
    anchors = spec.get("anchors_expected", [])
    lines = []
    # Enforce black & white storyboard and single panel
    lines.append("Storyboard panel. Black and white line art only. Minimal shading.")
    lines.append("Single panel only. Do NOT include multiple frames or borders.")
    # Camera + composition
    lines.append(f"Camera POV: {camera['mode']} from {camera['position_wall']} doorway facing {camera['facing_wall']}.")
    lines.append(f"Must show walls: {', '.join(comp['must_show_walls'])}. Must hide walls: {', '.join(comp['must_hide_walls'])}.")
    if comp.get("foreground_edges"):
        lines.append(f"Foreground edge: {', '.join(comp['foreground_edges'])}.")
    # Anchors with geometry
    for a in anchors:
        t = a.get("type")
        w = a.get("wall")
        region = a.get("region","")
        if t == "window":
            lines.append(f"Draw a {w} wall window positioned {region if region else 'center'} in frame.")
        if t == "bed":
            orient = a.get("orientation","horizontal")
            head = a.get("headboard_wall","N")
            # Explicit geometric instruction
            lines.append("BED LAYOUT: place bed under WEST wall window, oriented LEFT-to-RIGHT (horizontal).")
            lines.append("Headboard is flush against the NORTH wall and visible on the RIGHT side of the frame.")
            lines.append("Do NOT center the bed under the window if that would hide the headboard on the right.")
    # Characters rule
    if not ctrl.get("allow_characters", False):
        lines.append("No characters visible; environment layout only.")
    else:
        chs = spec.get("characters", [])
        if chs:
            names = ', '.join([c.get("id","") for c in chs])
            lines.append(f"Characters present: {names}.")
    return "\n".join(lines)
