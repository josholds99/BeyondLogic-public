
def expect_layout(facing: str):
    return {"W":{"center":"W","right":"N","left":"S"},
            "E":{"center":"E","right":"S","left":"N"},
            "N":{"center":"N","right":"E","left":"W"},
            "S":{"center":"S","right":"W","left":"E"}}.get(facing, {})

def lint_shot(spec: dict) -> list:
    errs = []
    layout = expect_layout(spec["camera"]["facing_wall"])
    comp = spec["composition"]
    if layout and layout["center"] not in set(comp["must_show_walls"]):
        errs.append(f"must_show_walls must include center wall {layout['center']} for facing {spec['camera']['facing_wall']}")
    if spec["camera"]["position_wall"] not in set(comp["must_hide_walls"]):
        errs.append(f"must_hide_walls must include position_wall {spec['camera']['position_wall']}")
    ctrl = spec.get("render_controls", {})
    if spec["camera"]["mode"] == "POV" and ctrl.get("allow_characters", False):
        errs.append("POV shots should set render_controls.allow_characters=false")
    return errs
