
def compile_prompt(spec: dict) -> str:
    ctrl = spec.get("render_controls", {"bw_only": True, "allow_characters": False, "single_panel_mode": True})
    camera = spec["camera"]
    comp = spec["composition"]
    anchors = spec.get("anchors_expected", [])
    lines = []
    # Enforce black & white
    lines.append("Storyboard panel, black and white line art, minimal shading." if ctrl.get("bw_only", True) else "Storyboard panel, clean line art.")
    # Enforce single panel
    if ctrl.get("single_panel_mode", True):
        lines.append("Single panel only. Do not include multiple frames or borders.")
    # Camera + composition
    lines.append(f"Camera POV: {camera['mode']} from {camera['position_wall']} doorway facing {camera['facing_wall']}.")
    lines.append(f"Must show walls: {', '.join(comp['must_show_walls'])}.")
    lines.append(f"Must hide walls: {', '.join(comp['must_hide_walls'])}.")
    if comp.get("foreground_edges"):
        lines.append(f"Foreground edge: {', '.join(comp['foreground_edges'])}.")
    # Anchors
    for a in anchors:
        if a.get("type") == "window":
            lines.append(f"{a['wall']} wall window positioned {a['region']} in frame.")
        if a.get("type") == "bed":
            lines.append("Bed horizontal under west wall window; headboard against north wall (right side).")
    # Characters rule
    if not ctrl.get("allow_characters", False):
        lines.append("No characters visible; environment layout only.")
    else:
        chs = spec.get("characters", [])
        if chs:
            names = ', '.join([c.get("id","") for c in chs])
            lines.append(f"Characters present: {names}.")
    lines.append("Cinematic composition.")
    return "\n".join(lines)
