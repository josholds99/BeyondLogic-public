
# ShotKit Guardrails (v20250916)

**Goal:** Make corrections safe and fast by hard-coding black & white, single-panel, and POV rules.**

## Workflow
1) Edit ONE shot_spec (see examples/).
2) Run guardrails lint (panel_lint.lint_shot) — fix errors first.
3) Build prompt (prompt_builder.compile_prompt) — it enforces B/W + single panel.
4) Render ONE panel only.
5) Approve -> lock; THEN assemble sheets.

## Flags
- render_controls.bw_only=true → black & white only, minimal shading.
- render_controls.allow_characters=false → for POV/environment-only shots (no people).
- render_controls.single_panel_mode=true → prohibits multi-frame combos.

## Examples
- examples/p12_p2_shot.json → POV from east doorway, window center, bed horizontal under west window (headboard on north/right). No characters.
- examples/p12_p1_shot.json → Hallway with Collin in frame, reaching door.
